var ballspec = {
  speed: 5,      // Speed of the ball (movement speed)
  health: 20,    // Health of the ball (durability or status)
  size: 3,       // Size of the ball (scale factor)
  aggro: 10,     // Aggro range (how far the ball can detect targets)
  model: "cobblemon:ultra_ball", // Model of the ball (model ID)
  defaultDetail: true, // If true, it will use the default detail size that I’ve set (not the same as “size”).
  skin: "customnpcs:textures/gui/invisible.png" // Transparent skin
};
var respawn = {
  enable: true,  // If true, NPC will respawn after death
  delay: 10      // Delay in seconds before NPC respawns
};
var sneakFlee = {
  allow: true,  // If true, NPC won't flee when the player is sneaking (crouching)
  angle: 90      // Angle range (in degrees) to consider the player "behind" the NPC
};
var showBackArc = false
var rewardList = [
  { type: "pokemon", name: "pikachu", disn: "Pikachu" },  // Reward: Pokémon (name and translated name)
  { type: "pokemon", name: "charizard", disn: "Charizard" },
  { type: "item", name: "minecraft:diamond_sword", count:1, disn: "Diamond Sword" },  // Reward: Item (name and translated name)
  { type: "money", amount: 100 }  // Reward: Money (amount)
];
var runType = {
  type: 2,  // Escape type (0: none (no movement), 1: Normal speed, 2: Dash, 3: Jump 4: Hide)
  dash: { speed: 2, cool: 3 },  // For type 2: Dash (cooldown in seconds, speed)
  jump: { hspd:1.2, jumpPower:0.7 , cool: 3 },  // For type 3: Jump and fall (jump height and fall speed)
  hide: { dur: 20, cool: 3}
};
var effect = {
  spawnSnd: "cobblemon:evolution.ui",  // Sound when Pokémon appears
  spawnPtcl: "minecraft:happy_villager",  // Particle effect when Pokémon appears
  ballSnd: "cobblemon:poke_ball.capture_succeeded",  // Sound when the pop Ball dies
  ballPtcl: "minecraft:poof",  // Particle effect when the pop Ball dies

  dashSnd: "minecraft:entity.player.attack.sweep",   // Dash sound
  jumpSnd: "minecraft:entity.slime.jump",             // Jump sound
  hideSnd: "minecraft:entity.enderman.teleport"       // Hide sound
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var API = Java.type("noppes.npcs.api.NpcAPI").Instance();
var TID = {AI:10,JUMP:30,HIDE:40,APPEAR:100} // Timer ID
var AIinterval = 5

function init(e) {
    var n = e.npc; var td = n.getTempdata();
    applyState(n); applySpec(n); 
    applySpawn(n); applyVisual(n) 
    n.updateClient()
    td.remove("done");
    td.put("CD", 0);         // Cooldown reset
    td.put("STATE", "none"); // Skill idle state
    n.timers.forceStart(TID.AI,AIinterval,true)
}

function died(e){
    var n = e.npc; var w = n.getWorld()
    w.spawnParticle(effect.ballPtcl,n.x, n.y + 0.5, n.z,0.1, 0.3, 0.1, 0.05,20); 
    if(respawn.enable == false) e.npc.despawn()}

function interact(e){
    var n = e.npc, p = e.player;
    var td = n.getTempdata();
    if(td.get("done")) return; // already captured / reward processed
    if(n.getArmor(3).isEmpty()) return; // hide-state (cannot be captured)
    lockdownNPC(n); // freeze NPC (lockdown)
    giveReward(n, p); // givereward 
}

function fleeCheck(n,t){
    var isBack = isBehind(n, t, sneakFlee.angle, showBackArc);
    if (sneakFlee.allow == true && t.isSneaking() && isBack == true) {return true}
    else {return false}
}

function target(e){
    var n = e.npc; var t = e.entity
    if(t.getType()==1 && fleeCheck(n,t)==true){
        n.setMotionX(0); n.setMotionY(0);  n.setMotionZ(0);
        n.ai.setRetaliateType(3)}}

function timer(e){
    var n = e.npc; var w = n.getWorld(); var td = n.getTempdata();
        // === AI ===
    if (e.id == TID.AI){
        var t = n.getAttackTarget();
        if (!t) return;
        if (td.get("STATE") != "none") return;
        if (fleeCheck(n,t) == true){
            n.setMotionX(0); n.setMotionY(0);  n.setMotionZ(0);
            n.ai.setRetaliateType(3)
        }    
        else{applyState(n); tryRunSkill(n, runType.type);}
    }
    // === Jump ===
    if (e.id == TID.JUMP){
        if (isGround(n)){
        td.put("CD", runType.jump.cool*20);
        td.put("STATE", "none");
        n.timers.stop(TID.JUMP);
        }
        return;
    }
    // === Hide ===
    if (e.id == TID.HIDE){
        var headItem = w.createItem(ballspec.model, 1);
        n.setArmor(3, headItem);
        td.put("CD", runType.hide.cool*20);
        td.put("STATE", "none");
        n.updateClient()
        return;
    }

}

function applyState(n){
    if (runType.type == 0) {n.ai.setRetaliateType(3)}
    else{n.ai.setRetaliateType(2)} 
}
function applySpec(n){
    var w = n.getWorld();
    var headItem = w.createItem(ballspec.model, 1); n.setArmor(3, headItem); 
    n.stats.setMaxHealth(ballspec.health);n.setHealth(ballspec.health);
    n.stats.setAggroRange(ballspec.aggro);
    n.ai.setWalkingSpeed(ballspec.speed);
    n.display.setSize(ballspec.size);  
    n.display.setSkinTexture(ballspec.skin)
}
function applyVisual(n){
    if (ballspec.defaultDetail !== true) return; 
    var d_head  = [1.5, 1.5, 1.5]; var d_other = [0.5, 0.5, 0.5];
    // 0:Head, 1:Body, 2:ArmLeft, 3:ArmRight, 4:LegLeft, 5:LegRight
    for (var part = 0; part <= 5; part++){
        var target = (part === 0) ? d_head : d_other;
        var cur = n.getDisplay().getModelScale(part);  // cur = [x, y, z]
        if (cur[0] === target[0] && cur[1] === target[1] && cur[2] === target[2]) continue;
        n.getDisplay().setModelScale(part, target[0], target[1], target[2]);
    }
}
function applySpawn(n){
    if (respawn.enable === false) {n.stats.setRespawnType(3);  // No respawn
    } else {n.stats.setRespawnType(0);}  // Auto respawn (default)
    n.stats.setRespawnTime(respawn.delay)    
}
function isBehind(n, t, backAngle, showArc){
    if (!t) return false;
    var yaw = n.getRotation();       // NPC facing
    var dx  = t.x - n.x;
    var dz  = t.z - n.z;
    var ang = Math.atan2(dz, dx) * 180 / Math.PI; ang = (ang + 360) % 360; // Direction from NPC → Target
    var back = (yaw + 180) % 360; // NPC back direction
    var diff = Math.abs(back - ang); // angle difference
    if (diff > 180) diff = 360 - diff;
    if (showArc === true) showBackArc(n, backAngle);
    if (diff <= backAngle) return true; // Return true or false explicitly
    return false;
}
function showBackArc(n, angleRange){
    var w = n.getWorld();
    var yaw = n.getRotation();
    var yawMath = (yaw + 90) % 360;
    var backDir = (yawMath + 180) % 360;
    var half = angleRange / 2;
    var radius = 2.5;
    var step = 4;
    for (var a = -half; a <= half; a += step) {
        var deg = (backDir + a + 360) % 360;
        var rad = deg * Math.PI / 180;
        var px = n.x + Math.cos(rad) * radius;
        var pz = n.z + Math.sin(rad) * radius;
        var py = n.y + 0.1;
        w.spawnParticle("minecraft:crit", px, py, pz, 0, 0, 0, 0, 1);
    }
}
function tryRunSkill(n, type){
    var td = n.getTempdata();

    var CD = td.get("CD") || 0;
    if (td.get("STATE") != "none") return;
    if (CD > 0){
        td.put("CD", Math.max(0, CD - AIinterval));
        return;
    }
    if (type == 2){      // Dash
        td.put("STATE", "dash");
        doDash(n);
        td.put("STATE", "none"); 
        return;
    }
    if (type == 3){      // Jump
        td.put("STATE", "jump");
        doJump(n);
        return;
    }
    if (type == 4){      // Hide
        td.put("STATE", "hide"); 
        doHide(n);
        return;
    }
}
function doDash(n){
    var td = n.getTempdata();
    td.put("CD", runType.dash.cool*20); 
    var ang = Math.random() * Math.PI * 2;
    var spd = runType.dash.speed;
    n.setMotionX(Math.cos(ang) * spd);
    n.setMotionZ(Math.sin(ang) * spd);
    n.getWorld().playSoundAt(n.getPos(), effect.dashSnd, 1, 1);
}
function doJump(n){
    var td = n.getTempdata();
    var ang = Math.random() * Math.PI * 2;
    var hspd = runType.jump.hspd
    var yspd = runType.jump.jumpPower
    n.setMotionX(Math.cos(ang) * hspd);
    n.setMotionZ(Math.sin(ang) * hspd);
    n.setMotionY(yspd);
    n.getWorld().playSoundAt(n.getPos(), effect.jumpSnd, 1, 1);
    n.timers.forceStart(TID.JUMP, 1, true);
}
function isGround(n){
    var tag = n.getEntityNbt();
    return tag.getBoolean("OnGround");
}
function doHide(n){
    var td = n.getTempdata();
    var w = n.getWorld();
    n.setArmor(3, w.createItem("minecraft:air", 1)); 
    w.playSoundAt(n.getPos(), effect.hideSnd, 1, 1);
    n.updateClient()
    n.timers.forceStart(TID.HIDE, runType.hide.dur, false);
}
function lockdownNPC(n){
    var td = n.getTempdata(); var w = n.getWorld()
    n.timers.clear(); td.clear();
    td.put("done", true);
    n.ai.setWalkingSpeed(0) //움직임 멈춤
    if(respawn.enable == false) n.ai.setAnimation(14); //사망 애니메이션
    n.ai.setRetaliateType(3); //응전태세 낫띵
}
function giveReward(n, p){
    var w = n.getWorld();
    var pick = rewardList[Math.floor(Math.random() * rewardList.length)]; // pick random reward
  
    if(pick.type === "pokemon") rewardPokemon(n, pick);
    if(pick.type === "item") rewardItem(n, p, pick);
    if(pick.type === "money") rewardMoney(n, p, pick);
    w.playSoundAt(n.getPos(), effect.ballSnd, 1, 1);
}
function rewardPokemon(n, pick){
    var w = n.getWorld();
    w.playSoundAt(n.getPos(), effect.spawnSnd, 1, 1);
    var x = n.x; var y = n.y + 0.5; var z = n.z;
    var cmd = "spawnpokemonat " + x + " " + y + " " + z + " " + pick.name; // spawn cobblemon
    API.executeCommand(w, cmd);
    w.spawnParticle(effect.spawnPtcl,x,y,z,0.1, 0.3, 0.1, 0.05,20);
    n.kill();
}
function rewardItem(n,p, pick){
    p.giveItem(pick.name,pick.count || 1);
    p.updatePlayerInventory()
    p.message("§aReceived Item: §f" + (pick.disn || pick.name));
    n.kill();
}
function rewardMoney(n,p, pick){
    var w = p.getWorld();
    var cmd = "cobbledollars give " + p.getName() + " " + pick.amount;
    API.executeCommand(w, cmd);
    p.message("§a+" + pick.amount + " Cobbledollars");
    n.kill();
}
